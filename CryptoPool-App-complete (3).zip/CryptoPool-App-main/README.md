# CryptoPool App 3.0

CryptoPool is a **testnet/demo DApp UI** using Reown AppKit + Wagmi + Ethereum Sepolia.

## What is fixed

- One wallet connection layer: Reown AppKit / WalletConnect.
- Desktop + mobile browser wallet flow.
- Wallet list shown by AppKit (`allWallets: "SHOW"`).
- Google login + Email login in the AppKit modal.
- Email wallet options enabled (`emailShowWallets: true`).
- Sepolia only for the demo (`11155111`).
- No seed phrase/private-key collection.
- No real-money swaps or investment transactions.
- Responsive mobile UI and bottom navigation.
- GitHub Pages base path preserved: `/CryptoPool-App/`.

## GitHub Pages

Repository: `https://github.com/Huong83/CryptoPool-App`

Expected site:
`https://huong83.github.io/CryptoPool-App/`

The existing GitHub Actions Pages workflow can remain in place.

## Reown setup (one-time)

The code accepts:

`VITE_REOWN_PROJECT_ID`

For GitHub Pages, a public project ID can be used in frontend configuration; **do not put API secrets/private keys in the repository**.

In the Reown Dashboard, make sure the project allows the domain:

`huong83.github.io`

For Google sign-in, enable Google/social authentication for the project. This is a dashboard setting, not a code edit.

Important: "Gmail connection" here means **Google authentication / Email authentication** through Reown AppKit. CryptoPool never asks for a Google password.

## Local test

```bash
npm install
npm run build
npm run dev
```

## Important

This package is intentionally testnet/demo-only. A successful wallet connection does not mean that a real investment or swap is enabled. Real-money functionality should only be added after smart-contract, transaction-simulation, security, and legal/compliance review.
